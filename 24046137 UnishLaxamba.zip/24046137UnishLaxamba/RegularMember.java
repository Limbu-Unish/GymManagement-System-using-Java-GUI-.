package _24046137_Unish_Laxamba;

/**
 * Root class for the Gym Management System.
 * This class contains the common attributes and methods for all gym members.
 * 
 * @author Unish Laksamba
 * @version 1.0
 * @since 2023 - 03 - 25
 */

//Regular member is subclass of Gymmember
class RegularMember extends GymMember
{   
    //Attributes of regular member
    private int attendanceLimit;
    private boolean isEligibleForUpgrade;
    private String removalReason;
    private String referralSource;
    private String plan;
    private double price;
    
    /**
     * Constructor for RegularMember.
     * @param id include the unique identifier for the regular member.
     * @param name include the name of the regular member.
     * @param location include the location of the regular member.
     * @param email include the email address of the regular member.
     * @param phone include the phone number of the regular member.
     * @param gender include the gender of the regular member.
     * @param DOB include the date of birth of the regular member.
     * @param membershipStartDate include the start date of the regular member's membership.
     * @param referralsource include the personal trainer assigned to the regular member.
     */
    public RegularMember(int id, String name, String location, String email, String phone, String gender, String DOB, String membershipStartDate, String referralSource){
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.attendanceLimit = 30;
        this.isEligibleForUpgrade = false;
        this.plan = "basic";
        this.price = 6500.0;
        this.removalReason = "";
        this.referralSource = referralSource;
    }
    
    //Getter method
    public int attendanceLimit(){
    return attendanceLimit;
    }

    public boolean getisEligibleForUpgrade(){
    return isEligibleForUpgrade;
    }

    public String getreferralSource(){
        return referralSource;
    }
    
    public String getremovalReason(){
        return removalReason;
    }
    
    public String getplan(){
        return plan;
    }

    public double getprice(){
        return price;
    }
    
    /**
     * A method that marks attendance of the members of regular member.
     * 
     * This method is Overrided and called from the parent class.
     * In this method the attendance is increased and loyalty points is increased by 5.
     */
    @Override
    public void markAttendance(){
        if(attendance < attendanceLimit){
            attendance++;
            loyaltyPoints += 5;
            System.out.println(name + "has done attendance. His/Her total attendance is :" + attendance);
            if(attendance == attendanceLimit){
            isEligibleForUpgrade = true;
            System.out.println(name + " is now eligible for an upgrade.");
            }
        } else {
            System.out.println(name + "has reached attendance limit of total :" + attendanceLimit);
        }
    }
    
    /**
     * A method to getplan price of the members.
     * 
     * @param in this method plan is selected as parameter and take type of plan which is selected.
     * @return returns double as the price amount for every types of plan.
     */
    public double getPlanPrice(String plan){
        switch(plan.toLowerCase()){
            case "basic":
            return 6500.0;
            
            case "standard":
            return 12500.0;
            
            case "deluxe":
            return 18500.0;
            
            default:
            System.out.println("Invalied plan is passed");
            return -1;
        }
    }
    
    /**
     * A method to upgrade the plan of the members
     * 
     * @param plan is selected as parameter in this method and takes amount to upgrade the plan.
     * @return returns String as the price to upgrade the plan price
     */
    public String upgradePlan(String Plan){
        
        if(!isEligibleForUpgrade){
            return"upgrade is not possible " + name + " has not reached his/her attendance limit yet";
        }
        
        if(Plan.equalsIgnoreCase(plan)){
            return"upgrade is not possible " + name + " has already subscribed to :" + Plan + "plan";
        }
        
        double newPrice = getPlanPrice(Plan);
        if(newPrice == -1){
            return "upgrade is not possible, invalid plan is selected";
        }
        
        this.plan = Plan;
        this.price = newPrice;
        return "upgrade is successful" + name + "has subscribed : " + plan + " plan at price : Rs" + price; 
        }
    
    /**
     * A method to revert the membership of the members of regular member.
     * 
     * @param in this method removalReason is used as parameter and takes the revomal reason to revert membership.
    **/
    public void revertRegularMember(String removalReason){
        resetMember();
        this.isEligibleForUpgrade = false;
        this.plan = "basic";
        this.price = 6500.0;
        this.removalReason = removalReason;
        System.out.println(name + "has reverted his/her plan to basic, Reason:" + removalReason);
    }
    
    /**
     * A method to show the details of every members of the regular member.
     * 
     * This method is Overrided and called from parent class.
     * @return returns String as the method of the super class and the details of the members.
     */
    @Override
    public String memberdetails(){
        
        return super.memberdetails()+
        "ReferralSource:   " + getreferralSource() + "\n" +
        "Plan:    " + getplan() + "\n";
        
        
    }
    
}
