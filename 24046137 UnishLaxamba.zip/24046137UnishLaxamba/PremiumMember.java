package _24046137_Unish_Laxamba;

/**
 * Root class for the Gym Management System.
 * This class contains the common attributes and methods for all gym members.
 * 
 * @author Unish Laksamba
 * @version 1.0
 * @since 2023 - 03 - 25
 */

// premium Member is set as subclass of gymmember
class PremiumMember extends GymMember
{   
    //Attributes of premium member
    private double premiumCharge;
    private String personalTrainer;
    private boolean isFullPayment;
    private double paidAmount;
    private double discountAmount;
    
    /**
     * Constructor for PremiumMember.
     * @param id include the unique identifier for the premium member.
     * @param name include the name of the premium member.
     * @param location include the location of the premium member.
     * @param phone include the phone number of the premium member.
     * @param email include the email address of the premium member.
     * @param gender include the gender of the premium member.
     * @param DOB include the date of birth of the premium member.
     * @param membershipStartDate include the start date of the premium member's membership.
     * @param personalTrainer include the personal trainer assigned to the premium member.
     */
    public PremiumMember(int id, String name, String location, String phone, String email, String gender, String DOB, String membershipStartDate, String personalTrainer){
        //Gymmember constructor is called
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        //intialize attributes
        this.premiumCharge = 50000.0;
        this.paidAmount = 0.0;
        this.isFullPayment = false;
        this.discountAmount = 0.0;
        this.personalTrainer = personalTrainer;
    }
    
    //getter methods
    public double getpremiumCharge(){
        return premiumCharge;
    }
    
    public String getpersonalTrainer(){
        return personalTrainer;
    }
    
    public boolean getisFullPayment(){
        return isFullPayment;
    }
    
    public double getdiscountAmount(){
        return discountAmount;
    }
    
    public double getpaidAmount(){
        return paidAmount;
    }
    
    /**
     * A methos to mark attendance of the members of Premium class
     * 
     * This method is Overrided and called from the super class.
     * In this method attendance is increased and loyalypoints is increased by 10.
     */
    @Override
    public void markAttendance(){
        attendance++;
        loyaltyPoints += 10;
    }
    
    /**
     * A method to pay deu amount of the members
     * 
     * @param paidAmount is selected as parameter which takes the amount paid by the members.
     * @return returns String as the value of the payment checked of the members.
     */
    public String payDeuAmount(double paidAmount){
        //Checked if the fullpayment is done or not
        if(isFullPayment){
            return "Payment is fully completed.";
        }
        
        //new payment is added to total paid amount
        this.paidAmount += paidAmount;
        
        //paid amount is checked whether it is less than premium charge or not
        if(this.paidAmount > premiumCharge){
            this.paidAmount -= paidAmount;
            return "Paid amount has exceeded the premium charge so the payment is declined.";
        }
        
        //remaining charge is calculated
        double remainingCharge = premiumCharge - paidAmount;
        
        //checked if paid amount is equal to prermium charge or not
        if(this.paidAmount == premiumCharge){
            isFullPayment = true;
            return "Payment is successful Full amount is paid.";
        }   else {
            isFullPayment = false;
            return "Payment is declined Full amount is not paid remaining amount to be paid: " + remainingCharge;
        }
    }
    
    /**
     * A method to calculate discount amount of the menbers.
     * 
     * @return returns String as the fullpayment is checked.
     */
    public String calculateDiscount(){
            //checking if isfullpayment is true or not
            if(this.isFullPayment){
                
                if (this.discountAmount > 0) {
                    return "Discount has already been applied. Discount amount was: Rs" + this.discountAmount;
                }
                this.discountAmount = 0.10 * this.premiumCharge;
                return "Discount is applied successfully, Discount amount is : Rs" + this.discountAmount;
            } else {
                this.discountAmount = 0.0;
                return "Discount is not applied, Please pay the deu amount first.";
            }
        }
    
    /**
     * A method to revert members of the premium member.
     */
    public void revertPremiumMember(){
        super.resetMember();
        this.personalTrainer = "";
        this.isFullPayment = false;
        this.paidAmount = 0.0;
        this.discountAmount = 0.0;
        System.out.println("Premium membership details is reset");
    }
    
    /**
     * A method to show details of the premium members.
     * This method is overrided and called from the parent class.
     * 
     * @return returns String as the methos of the super class and the details of the members.
     */
    @Override
    public String memberdetails(){
        return super.memberdetails() +
        "Personal Trainer:   " + getpersonalTrainer() + "\n";
    }
}
