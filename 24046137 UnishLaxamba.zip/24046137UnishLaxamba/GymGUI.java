package _24046137_Unish_Laxamba;

//Importing ArrayLiast from java toolkit
import java.util.ArrayList;

//Importing swing components from javax toolkit
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;


//Importing awt components from javax toolkit
import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.util.Iterator;
import java.io.File;
import java.nio.file.Files;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.List;

/**
 * Root class for the Gym Management System.
 * This class contains the common attributes and methods for all gym members.
 * 
 * @author Unish Laksamba
 * @version 1.0
 * @since 2023 - 03 - 25
 */

public class GymGUI
{
    private ArrayList<GymMember> members;

/**
 * Constructs a GymGUI object.
 * Initializes the members list to store gym member data.
 */
public GymGUI() {
    members = new ArrayList<>();
}
    
    private JFrame hero1;
    private JPanel hero2, hero, mainpanel, newmembers, filedisplay, reverting;
    private JTextArea displayArea, fileDisplayArea;
    private CardLayout cardLayout;

    // Form components
    private JTextField txtid, txtemail, txtname, txtlocation, txtphone, txtsource, txtamount, txtreason, txttname, txtplanprice, txtplanprice1, txtdiscount;
    private JRadioButton males, females;
    private JComboBox<String> complan, month, days, years, month1, days1, years1;
    private JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btn13, revertR, revertP;
    private CardLayout cardlay;
    private JTextArea display, displayf;

/**
 * The entry point of the application.
 * Launches the GymGUI on the Event Dispatch Thread using SwingUtilities.
 *
 * @param args command-line arguments (not used).
 */
public static void main(String[] args){
        SwingUtilities.invokeLater(() -> new GymGUI().createGUI());
        
}
   
/**
 * Creates and initializes the GUI for the Gym Management System.
 * 
 * Sets up the main application window, configures layout, and initializes 
 * all UI components and functionalities including:
 * - Heading panel
 * - Input fields
 * - Card panels for different views
 * - Button functionalities for regular and premium member operations
 * - Membership activation and deactivation
 * - Plan upgrades, discount calculations, and payment processing
 * - Data persistence (saving and loading from file)
 * 
 * Finally, adds all components to the main frame and makes the GUI visible.
 */
public void createGUI(){
        hero1 = new JFrame("GYM GUI");
        hero1.setSize(800, 800);
        hero1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        hero1.setLayout(new BorderLayout());
        
        headingpanel();
        allfeilds();
        cardpanels();
        cardlayoutbuttonfunction();
        addingregularmember();
        addingpremiummember();
        activatingmembership();
        deactivatingmembership();
        revertingrmember();
        revertingpmember();
        clearingtextfields();
        displaymembers();
        upgradingplan();
        calculatingdiscount();
        payingdueamount();
        savingdatatofile();
        displayingfromfile();
        setplanprice();
        loadDataFromFile();
        
        hero1.add(hero2, BorderLayout.NORTH);
        hero1.add(hero, BorderLayout.WEST);
        hero1.add(mainpanel, BorderLayout.CENTER);
        
        hero1.setVisible(true);
}
    
/**
 * Creates and configures the heading panel for the Gym Management GUI.
 * 
 * Initializes a JPanel with a fixed size and background color,
 * and adds a styled JLabel displaying the main title "GYM MANAGEMENT".
 */
public void headingpanel(){
        hero2 = new JPanel();
        hero2.setSize(9999, 100);
        hero2.setPreferredSize(new Dimension(999, 100));
        hero2.setBackground(new Color(61, 61, 61));
        
        //Label for panel heading
        JLabel lblhero = new JLabel("GYM MANAGEMENT");
        lblhero.setBounds(570, 30, 400, 30);
        lblhero.setForeground(Color.WHITE);
        lblhero.setFont(new Font(null, Font.BOLD, 35));
        hero2.add(lblhero);
}
   
/**
 * Initializes and configures all form input fields and buttons for the Gym Management GUI.
 * 
 * Sets up a panel containing labels, text fields, radio buttons, combo boxes, 
 * and control buttons to collect user input for member data such as:
 * - Personal information (ID, name, email, location, phone, gender, DOB)
 * - Membership start date
 * - Referral source and trainer name
 * - Membership plan selection and pricing
 * - Payment and discount details
 * - Removal reasons (if applicable)
 * 
 * Also creates and adds buttons for actions including:
 * - Adding regular/premium members
 * - Marking attendance
 * - Displaying member details
 * - Activating/deactivating membership
 * - Reverting members
 * - Clearing fields
 * - Saving and loading data from file
 * - Upgrading plans
 * - Calculating discounts
 * - Paying due amounts
 * 
 * All components are laid out manually using absolute positioning.
 */
public void allfeilds(){
    hero = new JPanel();
    hero.setPreferredSize(new Dimension(600, 800));
    hero.setBackground(new Color(255, 250, 236));
    hero.setBorder(BorderFactory.createLineBorder(new Color(61, 61, 61), 10));
    hero.setLayout(null);
        
    //Creating label for ID
    JLabel Id = new JLabel("Id: ");
    Id.setBounds(60, 50, 150, 30);
    
    //Creating textfield for ID
    txtid = new JTextField();
    txtid.setBounds(120, 50, 200, 30);
    
    //Creating label for email
    JLabel emails = new JLabel("Email: ");
    emails.setBounds(60, 80, 150, 30);
    hero.add(emails);
    
    //Creating textfield for email
    txtemail = new JTextField();
    txtemail.setBounds(120, 80, 200, 30);
    hero.add(txtemail);
    
    //Creating label for Name
    JLabel names = new JLabel("Name: ");
    names.setBounds(60, 110, 150, 30);
    
    //Creating Textfield for Name
    txtname = new JTextField();
    txtname.setBounds(120, 110, 200, 30);
    
    //Creating label for location
    JLabel location = new JLabel("Location: ");
    location.setBounds(60, 140, 150, 30);
    
    //Creating TextField for location
    txtlocation = new JTextField();
    txtlocation.setBounds(120, 140, 200, 30);
    
    //Creating label for phone number
    JLabel phones = new JLabel("Phone: ");
    phones.setBounds(60, 170, 150, 30);
    
    //Creating TextField for phone number
    txtphone = new JTextField();
    txtphone.setBounds(120, 170, 200, 30);
    
    //Creating label for gender
    JLabel genders = new JLabel("Gender");
    genders.setBounds(60, 200, 150, 30);
    
    //Creating option for radiobutton
    males = new JRadioButton("Male");
    males.setBounds(120, 200, 80, 30);
    
    //Creating option for radiobutton
    females = new JRadioButton("Female");
    females.setBounds(190, 200,100,30);
    
    //Selecting only one option of radiobutton
    ButtonGroup exclude = new ButtonGroup();
    exclude.add(males);
    exclude.add(females);
    
    //Creating DOB section
    JLabel DOBs = new JLabel("DOB: ");
    DOBs.setBounds(60, 230, 80, 30);
    
    //Creating Month section for DOB
    String [] number1 = {"January", "Feburary", "March", "April", "May", "June", "July", "August", "September", "Octuber", "November", "December"};
    month = new JComboBox<>(number1);
    month.setBounds(210, 230, 100, 30);
    
    //Creating year section for DOB
    String [] year = new String[31];
    //Using for loop for initializing value of years
    for (int i = 0; i < 31; i++){
        year[i] = String.valueOf(2000 + i);
    }
    years = new JComboBox<>(year);
    years.setBounds(110, 230, 100, 30);
    
    //Creating day section for DOB
    String [] day = new String[31];
    //Using for loop for initializing value of days
    for(int i = 0; i < 31; i++){
        day[i] = String.valueOf(i + 1);
    }
    days = new JComboBox<>(day);
    days.setBounds(310, 230, 100, 30);
    
    //Creating membership start date
    JLabel membershipdate = new JLabel("Membership Start Date: ");
    membershipdate.setBounds(60, 260, 180, 30);
    
    //Creating year section for Membershipstart date
    String [] memeyear = new String[31];
    //Using for loop
    for (int i = 0; i < 31; i ++){
        memeyear[i] = String.valueOf(2000 + i);
    }
    years1 = new JComboBox<>(memeyear);
    years1.setBounds(210, 260, 100, 30);
    
    //Creating month section for Membershipstart date
    String [] number3 = {"January", "Feburary", "March", "April", "May", "June", "July", "August", "September", "Octuber", "November", "December"};
    month1 = new JComboBox<>(number3);
    month1.setBounds(310, 260, 100, 30);
    
    //Creating day section for Membershipstart date
    String [] memeday = new String[31];
    //Using for loop
    for(int i = 0; i < 31; i++){
        memeday[i] = String.valueOf(i + 1);
    }
    days1 = new JComboBox<>(memeday);
    days1.setBounds(410, 260, 100, 30);
    
    //Creating label for referral source
    JLabel source = new JLabel("Referral Sources: ");
    source.setBounds(60, 290, 110, 30);
    
    //Creating textfield for referral source
    txtsource = new JTextField();
    txtsource.setBounds(170, 290, 200, 30);
    
    //Creating label for Paid Amount
    JLabel amount = new JLabel("Paid Amount: ");
    amount.setBounds(60, 320, 110, 30);
    
    //Creating Textfield for Paid Amount
    txtamount = new JTextField();
    txtamount.setBounds(170, 320, 200, 30);
    
    //Creating Label for Removal Reason
    JLabel removalReason = new JLabel("Removal Reason: ");
    removalReason.setBounds(60, 350, 110, 30);
    
    //Creating TextField for Removal Reason
    txtreason = new JTextField();
    txtreason.setBounds(170, 350, 200, 30);
    
    //Creating label for Trainername
    JLabel tname = new JLabel("Trainer Name: ");
    tname.setBounds(60, 380, 110, 30);
    
    //Creating textfield for trainer name
    txttname = new JTextField();
    txttname.setBounds(170, 380, 200, 30);
    
    //Creating label for plan
    JLabel plans = new JLabel("Plan (Regular Member Only): ");
    plans.setBounds(60, 410, 190, 30);
    
    //Creating attributes for plan
    String [] plans1 = {"Basic", "Standard", "Deluxe"};
    complan = new JComboBox<>(plans1);
    complan.setBounds(240, 410, 120, 30); 
    
    //Creating label for regular plan price
    JLabel planprice = new JLabel("Regular Plan price: ");
    planprice.setBounds(60, 440, 190, 30);
    
    //Creating textfield for regular plan price
    txtplanprice = new JTextField();
    txtplanprice.setBounds(180, 440, 200, 30);
    txtplanprice.setEditable(false);
    
    //Creating label for premium plan price
    JLabel planprice1 = new JLabel("Premium Plan price: ");
    planprice1.setBounds(60, 470, 190, 30);
    
    //Creating textfield for regular plan price
    txtplanprice1 = new JTextField("50000");
    txtplanprice1.setBounds(190, 470, 200, 30);
    txtplanprice1.setEditable(false);
    
    //Creating label for discount amount
    JLabel discounts = new JLabel("Discount: ");
    discounts.setBounds(60, 500, 190, 30);
    hero.add(discounts);
    
    //Creating textfield for discount amount
    txtdiscount = new JTextField();
    txtdiscount.setBounds(130, 500, 200, 30);
    txtdiscount.setEditable(false);
    hero.add(txtdiscount);
    
    //Adding contents to hero panel
    hero.add(Id);
    hero.add(txtid);
    hero.add(names);
    hero.add(txtname);
    hero.add(location);
    hero.add(txtlocation);
    hero.add(phones);
    hero.add(txtphone);
    hero.add(genders);
    hero.add(males);
    hero.add(females);
    hero.add(DOBs);
    hero.add(month);
    hero.add(years);
    hero.add(days);
    hero.add(membershipdate);
    hero.add(years1);
    hero.add(month1);
    hero.add(days1);
    hero.add(source);
    hero.add(txtsource);
    hero.add(amount);
    hero.add(txtamount);
    hero.add(removalReason);
    hero.add(txtreason);
    hero.add(tname);
    hero.add(txttname);
    hero.add(plans);
    hero.add(complan);
    hero.add(planprice);
    hero.add(txtplanprice);
    hero.add(planprice1);
    hero.add(txtplanprice1);
    
    //Creating buttons in the panel
    //Button used for adding regular member
    btn1 = new JButton("Add Regular Member");
    btn1.setBounds(20, 550, 150, 40);
    hero.add(btn1);
    
    //Button used for adding premium member
    btn2 = new JButton("Add Premium Member"); 
    btn2.setBounds(190, 550, 150, 40);
    hero.add(btn2);
    
    //Button used for marking attendance
    btn3 = new JButton("Mark Attendance"); 
    btn3.setBounds(20, 600, 150, 40);
    hero.add(btn3);
    
    //Button used for displaying member details
    btn4 = new JButton("Display"); 
    btn4.setBounds(190, 600, 150, 40);
    hero.add(btn4);
    
    //Button used for activating membership
    btn5 = new JButton("Active Membership");
    btn5.setBounds(20, 650, 150, 40);
    hero.add(btn5);
    
    //Button used for deactivating membership
    btn6 = new JButton("Deactive Membership");
    btn6.setBounds(190, 650, 150, 40);
    hero.add(btn6);
    
    //Button used for showing panel where revert button is placed for respective member type
    btn7 = new JButton("Revert Member");
    btn7.setBounds(20, 700, 150, 40);
    hero.add(btn7);
    
    //Button used for clearing text fields
    btn8 = new JButton("Clear");
    btn8.setBounds(190, 700, 150, 40);
    hero.add(btn8);
    
    //Button used to save the data to the file
    btn9 = new JButton("Save to File");
    btn9.setBounds(20, 750, 150, 40);
    hero.add(btn9);

    //Button used to read the data to the file
    btn10 = new JButton("Read from File");
    btn10.setBounds(190, 750, 150, 40);
    hero.add(btn10);
    
    //Button to upgrade the plan
    btn11 = new JButton("Upgrade Plan");
    btn11.setBounds(370, 550, 150, 40);
    hero.add(btn11);
    
    //Button used for calculating discount
    btn12 = new JButton("Calculate Discount"); 
    btn12.setBounds(370, 600, 150, 40);
    hero.add(btn12);
    
    //Button used for paying deu amount
    btn13 = new JButton("Pay Deu Amount");
    btn13.setBounds(370, 650, 150, 40);
    hero.add(btn13);
    }
    
/**
 * Initializes and configures all card-based panels for the Gym Management GUI using CardLayout.
 * 
 * This method sets up the following main views inside the `mainpanel`:
 * 
 * 1. **newmembers panel**: 
 *    - Displays member details using a non-editable `JTextArea`.
 *    - Includes a scrollable view via `JScrollPane` for better navigation.
 * 
 * 2. **filedisplay panel**:
 *    - Displays data loaded from an external file.
 *    - Contains a scrollable `JTextArea` to present file contents.
 * 
 * 3. **reverting panel**:
 *    - Contains buttons for reverting regular and premium memberships.
 *    - Serves as a dedicated view for reverting operations.
 * 
 * Each of these panels is styled, positioned, and added to the main `CardLayout` container, 
 * enabling dynamic panel switching within the application interface.
 */

    public void cardpanels(){
    //Creating panel for main panel
    mainpanel = new JPanel();
    cardlay = new CardLayout();
    mainpanel.setLayout(cardlay);
    
    //Creating panel for members details where dispaly textarea is kept
    newmembers = new JPanel();
    newmembers.setLayout(null);
    newmembers.setBackground(new Color(229, 229, 229));
    newmembers.setBorder(BorderFactory.createLineBorder(new Color(61, 61, 61), 10));
    
    //Labeling memberdetails in the member details panel
    JLabel head = new JLabel("Member Details: ");
    head.setBounds(30, 20,150, 30);
    newmembers.add(head);
    
    //Creating text area where the member details is displayed
    display = new JTextArea();
    display.setEditable(false);
    display.setBounds(30, 50, 750, 750);
    newmembers.add(display);
    
    //Creating srcollpane to make the text area scrollable 
    JScrollPane scrollpane = new JScrollPane(display);
    scrollpane.setBounds(30, 50, 780, 720);
    newmembers.add(scrollpane);
    
    //Creating panel for payment
    filedisplay = new JPanel();
    filedisplay.setLayout(null);
    filedisplay.setBackground(new Color(229, 229, 229));
    filedisplay.setBorder(BorderFactory.createLineBorder(new Color(61, 61, 61), 10));
    
    //Labeling filedisplay in the filedisplay panel
    JLabel filehead = new JLabel("File Data Display: ");
    filehead.setBounds(30, 20,150, 30);
    filedisplay.add(filehead);
    
    //Creating text area where the file details is displayed
    displayf = new JTextArea();
    displayf.setEditable(false);
    displayf.setBounds(30, 50, 750, 750);
    filedisplay.add(displayf);
    
    //Creating srcollpane to make the text area scrollable in filedisplay
    JScrollPane scrollpanef = new JScrollPane(displayf);
    scrollpanef.setBounds(30, 50, 780, 720);
    filedisplay.add(scrollpanef);
    
    //Creating panel for reverting membership
    reverting = new JPanel();
    reverting.setBackground(new Color(255, 250, 236));
    reverting.setBorder(BorderFactory.createLineBorder(new Color(61, 61, 61), 10));
    reverting.setLayout(null);
    
    //Creating button for reverting regular member
    revertR = new JButton("Revert Regular MemberShip");
    revertR.setBounds(310, 150, 200, 50);
    reverting.add(revertR);
    
    //Creating button to revert premium member
    revertP = new JButton("Revert Premium MemberShip");
    revertP.setBounds(310, 250, 200, 50);
    reverting.add(revertP);
    
    //Adding panels in mainpanel
    mainpanel.add(newmembers, "1");
    mainpanel.add(filedisplay, "2");
    mainpanel.add(reverting, "3");
}
    
/**
 * Configures the action listeners for navigation buttons to switch between 
 * different panels in the GUI using CardLayout.
 * 
 * This method links buttons to specific views:
 * 
 * - **btn4**: Switches to the "newmembers" panel to display current member details.
 * - **btn7**: Switches to the "reverting" panel for reverting membership options.
 * - **btn10**: Switches to the "filedisplay" panel to display data read from a file.
 * 
 * Each button uses an `ActionListener` to change the visible panel in `mainpanel` 
 * by invoking `CardLayout.show()`.
 */
    public void cardlayoutbuttonfunction(){
        
    //Making btn4 functional to open new panel for displaying member
    btn4.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            cardlay.show(mainpanel, "1");
        }
    });
    
    //Making btn7 functional to open new panel for reverting member
    btn7.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
             cardlay.show(mainpanel, "3");
        }
    });
    
    //Making btn10 functional to open new panel for displaying file data
    btn10.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            cardlay.show(mainpanel, "2");
        }
    });
}

/**
 * Sets the price of the selected regular membership plan in the corresponding text field.
 *
 * This method adds an `ActionListener` to the `complan` combo box that triggers whenever
 * the selected item changes. Based on the selected plan ("Basic", "Standard", or "Deluxe"),
 * it updates the `txtplanprice` field with the corresponding price:
 * 
 * - "Basic" → 6500
 * - "Standard" → 12500
 * - "Deluxe" → 18500
 * 
 * If no valid plan is selected, the field is cleared.
 */
public void setplanprice(){
    complan.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            String selectedPlan = (String) complan.getSelectedItem();
            switch (selectedPlan) {
            case "Basic":
                txtplanprice.setText("6500");
                break;
            case "Standard":
                txtplanprice.setText("12500");
                break;
            case "Deluxe":
                txtplanprice.setText("18500");
                break;
            default:
                txtplanprice.setText("");
        }
        }
    });
}

/**
 * Loads member data from a fixed-width formatted text file into the members list.
 * 
 * This method clears the current members list and reads the file line by line, skipping the header.
 * Each line is parsed into member attributes. Depending on the "plan" field, it creates either
 * a PremiumMember or RegularMember object and adds it to the members list.
 * 
 * If a line is invalid or cannot be parsed, it is skipped with an error message printed to standard error.
 * After successfully loading, it shows a message dialog indicating the number of loaded members.
 * If the file cannot be read, an error dialog is shown.
 * 
 * Note: Assumes a helper method `parseFixedWidthLine(String line)` exists to split the line correctly.
 */
public void loadDataFromFile() {
    File file = new File("/Users/unishlaxamba/Desktop/24046137UnishLaxamba/MemberList.txt");
    members.clear();
    
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
        String line;
        boolean isFirstLine = true;
        
        while ((line = reader.readLine()) != null) {
            if (isFirstLine) {
                isFirstLine = false;
                continue;
            }
            
            // Split line while preserving spaces in fields
            String[] parts = parseFixedWidthLine(line);
            
            if (parts.length < 18) {
                System.err.println("Skipping invalid line: " + line);
                continue;
            }
            
            try {
                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();
                String location = parts[2].trim();
                String phone = parts[3].trim();
                String email = parts[4].trim();
                String gender = parts[5].trim();
                String dob = parts[6].trim();
                String membershipStart = parts[7].trim();
                String plan = parts[8].trim();
                String referralSource = parts[17].trim();
                
                if (plan.equalsIgnoreCase("Premium")) {
                    String personalTrainer = parts[16].trim().equals("None") ? "No Trainer" : parts[16].trim();
                    PremiumMember member = new PremiumMember(
                        id, name, location, phone, email, 
                        gender, dob, membershipStart, personalTrainer
                    );
                    members.add(member);
                } else {
                    RegularMember member = new RegularMember(
                        id, name, location, email, phone, 
                        gender, dob, membershipStart, referralSource
                    );
                    members.add(member);
                }
            } catch (Exception e) {
                System.err.println("Error parsing line: " + line);
            }
        }
        
        JOptionPane.showMessageDialog(hero1, "Loaded " + members.size() + " members", 
            "Success", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(hero1, "Error reading file: " + ex.getMessage(),
            "Error", JOptionPane.ERROR_MESSAGE);
    }
}

/**
 * Parses a fixed-width formatted line into an array of strings based on predefined column widths.
 * 
 * Each segment of the line corresponds to a field with a fixed number of characters specified
 * by the widths array. If the line is shorter than expected, missing fields are filled with empty strings.
 * 
 * @param line The fixed-width formatted string line to parse.
 * @return An array of strings, each representing a field extracted from the line.
 */
private String[] parseFixedWidthLine(String line) {
    // Adjust these positions based on your actual format
    int[] widths = {5, 10, 10, 10, 20, 10, 20, 20, 8, 10, 10, 15, 10, 15, 15, 15, 20, 20};
    String[] parts = new String[widths.length];
    int pos = 0;
    
    for (int i = 0; i < widths.length; i++) {
        if (pos >= line.length()) {
            parts[i] = "";
        } else {
            int end = Math.min(pos + widths[i], line.length());
            parts[i] = line.substring(pos, end);
            pos += widths[i];
        }
    }
    return parts;
}

/**
 * Adds functionality to btn1 to add a new regular member to the members list.
 * 
 * When btn1 is clicked, this method collects input data from various text fields,
 * radio buttons, and combo boxes, validates the input (including checking for empty
 * fields, proper integer format for ID, and valid phone number format), and ensures
 * that no duplicate member ID exists before creating and adding a new RegularMember
 * object to the members list.
 * 
 * If any validation fails, appropriate error messages are shown using JOptionPane.
 * On successful addition, a confirmation message is displayed.
 */
public void addingregularmember(){
//Making the btn1 functionable to add the member to the regular member list when clicked
btn1.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e){
        String id = txtid.getText().trim();    //Getting input from the respected textfields
        String name = txtname.getText();
        String address = txtlocation.getText();
        String email = txtemail.getText();
        String phone = txtphone.getText().trim();
        String gender = males.isSelected() ? "Male" : females.isSelected() ? "Female" : ""; //getting input from the gender radio button
        String DOBday = (String) days.getSelectedItem();        //getting input from the DOB comboboxes
        String DOBmonth = (String) month.getSelectedItem();
        String DOByear = (String) years.getSelectedItem();
        String dob = DOBday + " " + DOBmonth + " " + DOByear;   //Concating the inputted values
        String Membershipday = (String) days1.getSelectedItem();
        String Membershipmonth = (String) month1.getSelectedItem();
        String Membershipyear = (String) years1.getSelectedItem();
        String membershipStartDate = Membershipday + " " + Membershipmonth + " " + Membershipyear;
        String referralSources = txtsource.getText();

    //Using for loopto check if the needed text filed is empty or not
    if (id.isEmpty() || name.isEmpty() || address.isEmpty() || email.isEmpty() || phone.isEmpty() || gender.isEmpty() || dob == null || membershipStartDate == null || 
    referralSources.isEmpty()) {
        JOptionPane.showMessageDialog(hero1, "Please fill in all required fields needed for Regular Member before adding a member.", "Input Error", JOptionPane.ERROR_MESSAGE);
        return; // Stop execution if any field is empty
    }
    int txtids;
    try{
    txtids = Integer.parseInt(id);
    } catch (NumberFormatException n){
        JOptionPane.showMessageDialog(hero1, "Enter integer in ID instead of string", "Error in input", JOptionPane.ERROR_MESSAGE);
        return;
    };
    
    // make sure that the entered phone is integer and exactly 10
    if(phone.matches("\\d{10}")){
    
    } else {
            JOptionPane.showMessageDialog(hero1, "The phone number must be exactly 10 digits. Please enter a valid phone number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
    }
    boolean exists = false;
    //Using for loop in  members to check if there is duplicate memnber id or not
    for (GymMember member : members) {
    if (member.getID() == txtids) {
        exists = true;
        break; // Stop if the member is found.
     }
    }
    //If the duplicate id dont exists the member is added to the regular members list
    if(!exists){
        RegularMember newmember = new RegularMember(txtids, name, address, email, phone, gender, dob, membershipStartDate, referralSources);
        members.add(newmember);
        JOptionPane.showMessageDialog(hero1, "Regular Member added successfully");
        return;
    } else {
        JOptionPane.showMessageDialog(hero1, "Member with Id:  " + id + "  is already added in the Member list");
        return;
        }
    }   
});
}

/**
 * Adds functionality to btn2 to add a new premium member to the members list.
 * 
 * When btn2 is clicked, this method collects input data from various text fields,
 * radio buttons, and combo boxes, validates the input (including checking for empty
 * fields, proper integer format for ID, and valid phone number format), and ensures
 * that no duplicate member ID exists before creating and adding a new PremiumMember
 * object to the members list.
 * 
 * If any validation fails, appropriate error messages are shown using JOptionPane.
 * On successful addition, a confirmation message is displayed.
 */
public void addingpremiummember(){
    //Making the bth2 functionable which adds the member to the premium member list when clicked
    btn2.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
        String id = txtid.getText().trim();    //Getting input from the respected textfields
        String name = txtname.getText();
        String address = txtlocation.getText();
        String email = txtemail.getText();
        String phone = txtphone.getText().trim();
        String gender = males.isSelected() ? "Male" : females.isSelected() ? "Female" : ""; //getting input from the gender radio button
        String DOBday = (String) days.getSelectedItem();        //getting input from the DOB comboboxes
        String DOBmonth = (String) month.getSelectedItem();
        String DOByear = (String) years.getSelectedItem();
        String dob = DOBday + " " + DOBmonth + " " + DOByear;   //Concating the inputted values
        String Membershipday = (String) days1.getSelectedItem();
        String Membershipmonth = (String) month1.getSelectedItem();
        String Membershipyear = (String) years1.getSelectedItem();
        String membershipStartDate = Membershipday + " " + Membershipmonth + " " + Membershipyear;
        String personalTrainer = txttname.getText();
    //Using for loop to check weather the needed textfields are empty or not
    if (id.isEmpty() || name.isEmpty() || address.isEmpty() || email.isEmpty() || phone.isEmpty() || gender.isEmpty() || dob == null || membershipStartDate == null || personalTrainer.isEmpty()) {
        JOptionPane.showMessageDialog(hero1, "Please fill in all required fields before adding a member.", "Input Error", JOptionPane.ERROR_MESSAGE);
        return; // Stop execution if any field is empty
    }   else if ( phone.length() < 10 || phone.length() > 11){
        JOptionPane.showMessageDialog(hero1, "The phone number must be exactly than 10 digits.", "Input Error", JOptionPane.ERROR_MESSAGE);
        return;
    } 
    //Using try and catch to make sure the id intered is an integer
    int txtids;
    try{
    txtids = Integer.parseInt(id);
    }  catch (NumberFormatException n){
        JOptionPane.showMessageDialog(hero1, "Enter the Id in integer instead of string", "Error in the input", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // make sure that the entered phone is integer and exactly 10
    if(phone.matches("\\d{10}")){
    
    } else {
            JOptionPane.showMessageDialog(hero1, "The phone number contains invalid characters. Please enter a valid phone number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
    }
    
    boolean exists = false;
    //Using for loop in  members to check if there is duplicate memnber id or not
    for (GymMember member : members){
        if(member.getID() == txtids){
            exists = true;
            break;
        }
    }
    //if the duplicate id doesnot exist the member is added to the premimum member list
    if(!exists){
        PremiumMember newPMember = new PremiumMember(txtids, name, address, phone, email, gender, dob, membershipStartDate, personalTrainer);
        members.add(newPMember);
        JOptionPane.showMessageDialog(hero1, "Premium member added Successfully! ");
        return;
    } else {
        JOptionPane.showMessageDialog(hero1, "Member with Id:  " + id + "  is already added in the Member list");
        return;
        }
    }
    });
}

/**
 * Adds functionality to btn5 to activate a member's membership.
 * 
 * When btn5 is clicked, this method prompts the user to input a member ID via a dialog.
 * It validates the input to ensure it is not empty and is a numeric integer.
 * Then, it searches the members list for a member with the given ID.
 * 
 * If the member is found and their membership is not already active, it activates the membership
 * and shows a confirmation message. If the membership is already active, it informs the user.
 * If no member with the given ID exists, it displays an error message.
 * 
 * Appropriate error messages are shown for invalid or missing input.
 */
public void activatingmembership(){
    //Making the btn5 functionable which activates the membership of the member
    btn5.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            //Gets the id from the Joptioninputdialog from the user
            String id = JOptionPane.showInputDialog("Please enter the ID: ");
            //Checking if the id is empty or not
            if(id.isEmpty()){
                JOptionPane.showMessageDialog(hero1, "Enter the id properly", "Input error" , JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int txtid;
            //Using try and catch to make sure the id is integer
            try{
                txtid = Integer.parseInt(id);
            } catch (NumberFormatException n){
                JOptionPane.showMessageDialog(hero1, "Enter the numberic value in the ID instead of words", "Error in input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean found = false;
            //Using for loop in  members to check if there is duplicate memnber id or not
            for(GymMember member : members){
                if (member.getID() == txtid){
                    found = true;
                    //Checking if the id matches to the member stored in the regular member or premium member list
                    if ( member instanceof RegularMember || member instanceof PremiumMember){
                        if (member.activeStatus()){
                        JOptionPane.showMessageDialog(hero1,"Id: " + txtid + "  Membership is already activated.", "Error found", JOptionPane.ERROR_MESSAGE);
                        } else {
                        member.activeMembership();  
                        System.out.println(txtid + "Member active: " + member.activeStatus);
                        JOptionPane.showMessageDialog(hero1, "Membership activated of ID: " + txtid);
                        return;
                        }
                }
            }
        }
        //Checking if the id is not found  
        if (!found){
                JOptionPane.showMessageDialog(hero1, "Member with ID: " + id + "   is not Found", "Error in finding member id", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
    });
}

/**
 * Adds functionality to btn6 to deactivate a member's membership.
 * 
 * When btn6 is clicked, this method prompts the user to input a member ID via a dialog.
 * It validates the input to ensure it is not empty and is a numeric integer.
 * Then, it searches the members list for a member with the given ID.
 * 
 * If the member is found and their membership is currently active, it deactivates the membership
 * and displays a confirmation message. If the membership is already inactive, it informs the user.
 * If no member with the given ID exists, it displays an error message.
 * 
 * Appropriate error messages are shown for invalid or missing input.
 */
public void deactivatingmembership(){
    //Making the btn6 functionable which deactivates the membership
    btn6.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            //Getting the id from the user
            String id = JOptionPane.showInputDialog("Enter the ID: ");
            //Checking if the id is empty or not
            if(id.isEmpty()){
                JOptionPane.showMessageDialog(hero1 ,"The id mustnot be empty", "Error found", JOptionPane.ERROR_MESSAGE); 
                return;
            }
            
            int txtid;
            //Using try and catch to make sure the id is integer
            try{
                txtid = Integer.parseInt(id);
            } catch (NumberFormatException n){
                JOptionPane.showMessageDialog(hero1, "The ID must be numberic" , "Error found", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean found = false;
            //Using for loop in  members to check if there is duplicate memnber id or not
            for(GymMember member : members){
                if (member.getID() == txtid){
                    found = true;
                    //Checking if the id matches to the member stored in the regular member or premium member list
                    if ( member instanceof RegularMember || member instanceof PremiumMember){
                        if (member.activeStatus()){
                            member.deactiveMembership();
                            System.out.println(txtid + "Member deactive: " + member.activeStatus);
                            JOptionPane.showMessageDialog(hero1, "ID :" + txtid + "Membership is deactivated");
                            return;
                        } else {
                            JOptionPane.showMessageDialog(hero1, "Membership is already deactivated of ID: " + id , "Error found", JOptionPane.ERROR_MESSAGE);
                            return;
                        } 
                    }  
                }
            //Checking if the id is found or not
            if (!found){
                    JOptionPane.showMessageDialog(hero1, "Member with ID: " + id + "   is not Found", "Error in finding member id", JOptionPane.ERROR_MESSAGE);
                    return;
            }
        }
        }
    });
}

/**
 * Adds functionality to btn3 to mark attendance for a member.
 * 
 * When btn3 is clicked, this method prompts the user to enter a member ID.
 * It validates that the input is not empty and is a valid integer.
 * 
 * It then searches the members list for a member with the given ID.
 * If found and the member's membership is active, it marks the attendance and shows a confirmation message.
 * If the membership is not active, it notifies the user accordingly.
 * If the member ID is not found, it shows an error message.
 * 
 * Appropriate error dialogs are shown for invalid input or missing member ID.
 */
public void markingattendance(){
    //Making the btn3 functionable which marks attendance of the members
    btn3.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            //Getting the id from the user
            String id = JOptionPane.showInputDialog("Enter the ID: ");
            //Checking if the id is empty or not
            if(id.isEmpty()){
                JOptionPane.showMessageDialog(hero1, "The ID must not be Empty", "Error found", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            int txtid;
            //Using try and catch to make sure the inputed id is integer
            try{
                txtid = Integer.parseInt(id);
            }   catch(NumberFormatException n) {
                JOptionPane.showMessageDialog(hero1, "The ID must be integer instead of string", "Error found", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean exists = false;
            //Using for loop in  members to check if there is duplicate memnber id or not
            for(GymMember member : members){
                if(member.getID() == txtid){
                    //Checking if the member membership is active or not
                    if(member.activeStatus){
                        member.markAttendance();
                        JOptionPane.showMessageDialog(hero1,"Member with ID: " + txtid + " Attendance has been marked");
                        return;
                    } else {
                        JOptionPane.showMessageDialog(hero1,"Member with ID: " + txtid + " Membership has not been activated");
                        return;
                    }
                }
            }
            //Checking if the id exists or not
            if(!exists){
                JOptionPane.showMessageDialog(hero1, "Member with ID: " + id + "   is not found", "Error found", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
    });
}

/**
 * Adds functionality to the revertR button to revert a regular member.
 * 
 * When revertR is clicked, this method prompts the user to enter a member ID.
 * It validates that the ID is not empty and is a valid integer.
 * 
 * It then retrieves the reason for reverting from a text field and checks that it is not empty.
 * 
 * The method searches the members list for a regular member with the given ID.
 * If found, it calls the revertRegularMember method on that member with the given reason,
 * removes the member from the list, and shows a confirmation message.
 * 
 * If no matching regular member is found or inputs are invalid, it displays appropriate error messages.
 */
public void revertingrmember(){
    //Making the revertR fuctionable which reverts the regular member
    revertR.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            //Getting the id from the user
            String id = JOptionPane.showInputDialog("Enter the ID: ");
            //Checking if the id is empty or not
            if(id.isEmpty()){
                JOptionPane.showMessageDialog(hero1, "The ID must not be empty");
                return;
            }
            
            int txtids;
            //Using try and catch to makesure the inputed id is integer
            try{
                txtids = Integer.parseInt(id);
            } catch(NumberFormatException n){
                JOptionPane.showMessageDialog(hero1, "The ID must be Integer instead of string", "Error Found", JOptionPane.ERROR_MESSAGE);
                return;
            }
        
            String reason = txtreason.getText();        //Getting the reason from the textfield
            //Checking if the reason is null or empty
            if(reason == null || reason.isEmpty()){
                JOptionPane.showMessageDialog(hero1, "Reason cannot be empty.", "Error found", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            boolean found = false;
            Iterator<GymMember> iterator = members.iterator();
            while (iterator.hasNext()) {
            GymMember member = iterator.next();
            if (member.getID() == txtids && member instanceof RegularMember) {
                
                RegularMember regularmember = (RegularMember) member;
                regularmember.revertRegularMember(reason);
                
                iterator.remove();
                
                JOptionPane.showMessageDialog(hero1, "Regular Member with ID " + id + " has been removed.");
                found = true;
                break;
            }
        }
        
        if(!found){
            JOptionPane.showMessageDialog(hero1, "Regular member of " + id + "  is not found" , "Error found",  JOptionPane.ERROR_MESSAGE);
            return;
            }
        }
    });
}

/**
 * Adds functionality to the revertP button to revert a premium member.
 * 
 * When revertP is clicked, this method prompts the user to enter a member ID.
 * It validates that the ID is not empty and is a valid integer.
 * 
 * The method searches the members list for a premium member with the given ID.
 * If found, it calls the revertPremiumMember method on that member,
 * removes the member from the list, and shows a confirmation message.
 * 
 * If no matching premium member is found or inputs are invalid, it displays appropriate error messages.
 */
public void revertingpmember(){
  //Making the premium member revert button functionable
    revertP.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            String id = JOptionPane.showInputDialog(hero1, "Enter the ID: ");
            
            if (id == null || id.isEmpty()){
                JOptionPane.showMessageDialog(hero1, "The id mustnot be empty", "Error in input", JOptionPane.ERROR_MESSAGE);
            }
            
            int txtid;
            try{
                txtid = Integer.parseInt(id);
            } catch(NumberFormatException n) {               
                JOptionPane.showMessageDialog(hero1, "The id must be integer instead of string", "Error in input", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
    
            boolean found = false;
            Iterator<GymMember> iterator = members.iterator();
            while (iterator.hasNext()) {
            GymMember member = iterator.next();
            if (member.getID() == txtid && member instanceof PremiumMember) {
                PremiumMember premiummember = (PremiumMember) member;
                premiummember.revertPremiumMember();
                
                iterator.remove();
                
                JOptionPane.showMessageDialog(hero1, "Premium Member with ID " + id + " has been removed.");
                found = true;
                break;
            }
        }
        if(!found){
            JOptionPane.showMessageDialog(hero1, "Premium member of ID: " + id + "  is not found", "Error found",  JOptionPane.ERROR_MESSAGE);
            return;
        }   
        }
    });  
}

/**
 * Adds functionality to the btn8 button to clear all input fields.
 * 
 * When btn8 is clicked, this method resets all text fields, radio buttons, and combo boxes
 * to their default empty or initial states, effectively clearing any user input.
 */
public void clearingtextfields(){
    btn8.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
        txtid.setText("");
        txtemail.setText("");
        txtname.setText("");
        txtlocation.setText("");
        txtphone.setText("");
        txtsource.setText("");
        txtamount.setText("");
        txtreason.setText("");
        txttname.setText("");
        txtplanprice.setText("");
        txtdiscount.setText("");

        males.setSelected(false);
        females.setSelected(false);

        days.setSelectedIndex(0);
        month.setSelectedIndex(0);
        years.setSelectedIndex(0);

        days1.setSelectedIndex(0);
        month1.setSelectedIndex(0);
        years1.setSelectedIndex(0);

        complan.setSelectedIndex(0);
        }
    });
}

/**
 * Adds functionality to the btn11 button to upgrade a regular member's plan.
 * 
 * When btn11 is clicked, this method prompts the user to enter a member ID,
 * then attempts to find the member in the list. If the member is found and is 
 * an active RegularMember, their plan is upgraded to the selected plan from the combo box.
 * Appropriate messages are shown if the ID is invalid, the member is inactive,
 * the member is not a RegularMember, or if the member ID is not found.
 */
public void upgradingplan(){
    btn11.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String enteredId = JOptionPane.showInputDialog("Enter the ID: ");
        String Plan = (String) complan.getSelectedItem();
        System.out.println("Selected Plan: " + Plan);

        if (enteredId == null || enteredId.isEmpty()){
            JOptionPane.showMessageDialog(hero1, "The id mustnot be empty", "Error in input", JOptionPane.ERROR_MESSAGE);
            return;
            }
        int txtids;
        try{
        txtids = Integer.parseInt(enteredId);
        }  catch (NumberFormatException n){
        JOptionPane.showMessageDialog(hero1, "Enter the Id in integer instead of string", "Error in the input", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        boolean found = false;

        for (GymMember member : members) {
            if (member.getID() == txtids ) {
                found = true;
                if (member instanceof RegularMember) {
                    RegularMember regMember = (RegularMember) member;
                    if (regMember.activeStatus()) {
                        String result = regMember.upgradePlan(Plan);
                        JOptionPane.showMessageDialog(hero1, result);
                    } else {
                        JOptionPane.showMessageDialog(hero1, "Member is not active. Cannot upgrade.");
                        return;
                    }
                } else {
                    JOptionPane.showMessageDialog(hero1, "Only Regular Members can upgrade plans.");
                    return;
                }
                break;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(hero1, "Member ID not found.");
            return;
        }
    }
});
}

/**
 * Adds functionality to the btn4 button to display all members' details.
 * 
 * When btn4 is clicked, this method checks if the members list is empty or null.
 * If empty, it displays a message indicating the member list is empty.
 * Otherwise, it builds a string containing the details of each member separated
 * by a line and sets this string in the display text area, scrolling to the top.
 */
public void displaymembers(){
    //Making the display button functionable
    btn4.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            
            if (members == null || members.isEmpty() ){
               
                display.setText("Member List is empty");
                display.setCaretPosition(0);
                return;
            }
            
            StringBuilder memberslist = new StringBuilder();
            for(GymMember member : members){
                memberslist.append(member.memberdetails())
                .append("___________________________________________________________________").append("\n");
            }
            
            display.setText(memberslist.toString());
            display.setCaretPosition(0);
        }
    });
}

/**
 * Adds functionality to the btn12 button to calculate and display the discount
 * for a Premium Member based on their Member ID.
 * 
 * When btn12 is clicked, it prompts the user to enter a Member ID.
 * It validates the input, ensuring it is a non-empty integer.
 * Then, it searches the members list for a matching member.
 * If found and the member is a Premium Member, it calculates the discount and
 * displays it in a message dialog.
 * If the member is not a Premium Member or the ID is not found, an appropriate
 * error message is shown.
 */
public void calculatingdiscount(){
    // making the calculate discount button functionable
    btn12.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        String enteredId = JOptionPane.showInputDialog("Enter the Member ID:");

        // Input validation
        if (enteredId == null || enteredId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(hero1, "Please enter a valid Member ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int txtids;
        try {
            txtids = Integer.parseInt(enteredId.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(hero1, "Member ID must be an integer.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Search for member
        boolean found = false;
        for (GymMember member : members) {
            if (member.getID() == txtids) {
                found = true;
                if (member instanceof PremiumMember) {
                    PremiumMember premember = (PremiumMember) member;
                    String message = premember.calculateDiscount();  // Call the method
                    JOptionPane.showMessageDialog(hero1, "Discount for " + premember.getname() + ": Rs" + message);
                } else {
                    JOptionPane.showMessageDialog(hero1, "This feature is only available for Premium Members.");
                    return;
                }
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(hero1, "Member ID not found.");
            return;
        }
    }
});
}

/**
 * Adds functionality to the btn13 button to allow Premium Members to pay their due amounts.
 * 
 * When btn13 is clicked, it prompts the user to enter a Member ID and validates the input.
 * It searches the members list for the member with the given ID.
 * If the member is found and is a Premium Member, it then prompts the user to enter
 * the amount to pay, validates the amount, and processes the payment.
 * The payment status is then displayed in a message dialog.
 * 
 * If the entered ID is invalid, not found, or the member is not a Premium Member,
 * appropriate error messages are shown.
 */
public void payingdueamount(){
    //making the paydeuamount button functionable
    btn13.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        //Takes id as input from the user     
        String inputId = JOptionPane.showInputDialog("Enter Member ID: ");
        if (inputId == null || inputId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(hero1, "Member ID cannot be empty.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(inputId.trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(hero1, "Invalid ID. Please enter a valid integer.");
            return;
        }

        boolean found = false;
        for (GymMember member : members) {
            if (member.getID() == id) {
                found = true;
                //checks if instance of premium member
                if (member instanceof PremiumMember) {          
                    PremiumMember premember = (PremiumMember) member;

                    String inputAmount = JOptionPane.showInputDialog("Enter amount to pay:");
                    double amount;
                    try {
                        amount = Double.parseDouble(inputAmount);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(hero1, "Invalid amount.");
                        return;
                    }

                    String paymentStatus = premember.payDeuAmount(amount);
                    JOptionPane.showMessageDialog(hero1, paymentStatus);
                    return;
                } else {
                    JOptionPane.showMessageDialog(hero1, "This member is not a Premium Member.");
                    return;
                }
            }
        }

        if(!found){
            JOptionPane.showMessageDialog(hero1, "Member ID not found.");
            return;
        }
    }
});
}


/**
 * Adds functionality to the btn9 button to save all current member details to a text file.
 * 
 * When btn9 is clicked, it writes member information to a specified file on disk.
 * If the file is empty or new, a header row with column titles is written first.
 * Then, it iterates through the members list and writes each member's details
 * formatted in aligned columns, including both Regular and Premium member-specific fields.
 * 
 * Upon successful writing, a confirmation dialog displays the number of members saved.
 * If an IOException occurs during file writing, an error dialog is shown with the exception message.
 */
public void savingdatatofile(){
    //Making the save to file button functionable
btn9.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        File file = new File("/Users/unishlaxamba/Desktop/24046137UnishLaxamba/MemberList.txt");
            // Proceed with writing if no duplicates
            try (FileWriter writer = new FileWriter(file, true)) {
                // Write header only if file is empty/new
                if (file.length() == 0) {
                    writer.write(String.format("%-5s %-10s %-10s %-10s %-20s %-10s %-20s %-20s %-8s %-10s %-10s %-15s %-10s %-15s %-15s %-15s %-20s %-20s%n",
                        "ID", "Name", "Location", "Phone", "Email", "Gender", "DOB", "Membership Start",
                        "Plan", "Price", "Attendance", "Loyalty Points", "Active",
                        "Full Payment", "Discount", "Net Paid", "PersonalTrainer", "ReferralAource"));
                }

                // Write all current members after we had make sure that no dublicates ids are found
                for (GymMember member : members) {
                    writer.write(String.format("%-5d %-10s %-10s %-10s %-20s %-10s %-20s %-20s %-8s %-10s %-10d %-15.2f %-10s %-15s %-15s %-15s %-20s %-20s%n",
                        member.getID(),
                        member.getname(),
                        member.getlocation(),
                        member.getphone(),
                        member.getemail(),
                        member.getgender(),
                        member.getDOB(),
                        member.getmembershipStartDate(),
                        (member instanceof RegularMember) ? ((RegularMember)member).getplan() : "Premium",
                        (member instanceof RegularMember) ? String.format("%.2f", ((RegularMember)member).getprice()) : String.format("%.2f", ((PremiumMember)member).getpremiumCharge()),
                        member.getAttendance(),
                        member.loyaltyPoints(),
                        member.activeStatus() ? "Yes" : "No",
                        (member instanceof RegularMember) ? "N/A" : (((PremiumMember)member).getisFullPayment() ? "Yes" : "No"),
                        (member instanceof RegularMember) ? "N/A" : String.format("%.2f", ((PremiumMember)member).getdiscountAmount()),
                        (member instanceof RegularMember) ? "N/A" : String.format("%.2f", ((PremiumMember) member).getpaidAmount()),
                        (member instanceof RegularMember) ? "None" : String.format("%.2f", ((PremiumMember) member).getpersonalTrainer()),
                        (member instanceof RegularMember) ? ((RegularMember)member).getreferralSource() : "none"));
                }
    
                //Shows successful message after the member details is added in the file
                JOptionPane.showMessageDialog(hero1, members.size() + " new member details successfully added to file.","Success",JOptionPane.INFORMATION_MESSAGE);

                //Handle exception if the file is not written properly
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(hero1,"Error writing to file: " + ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
            }
    }
});
}

/**
 * Adds functionality to btn10 to display member data from a file in a new panel.
 * 
 * When btn10 is clicked, this method attempts to read the member data file from disk.
 * - If the file does not exist, an error dialog is shown.
 * - If the file is empty, a message indicating no data is displayed.
 * - Otherwise, the file content is read line by line and displayed in the displayf text area,
 *   using a monospaced font for proper alignment.
 * 
 * If an IOException occurs during reading, an error dialog is shown with the exception details.
 */
public void displayingfromfile(){
    //Making btn10 functional to open new panel for displaying file data
btn10.addActionListener(new ActionListener(){
    @Override
    public void actionPerformed(ActionEvent e){
    //Using the file
    File file = new File("/Users/unishlaxamba/Desktop/24046137UnishLaxamba/MemberList.txt");
    
    //Check if the file exist or not
    if (!file.exists()) {
        JOptionPane.showMessageDialog(hero1, "No member file found!","Error",JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    try{
        //Creates a lis of the lines in the file
        List<String> lines = Files.readAllLines(file.toPath());
        
        //Checks if the file is written or is empty
        if (lines.isEmpty()) {
            displayf.setText("No member data found in file.");
        } else {
            // Format with monospaced font for alignment
            displayf.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
            StringBuilder sb = new StringBuilder();
            for (String line : lines) {
                sb.append(line).append("\n");
            }
            displayf.setText(sb.toString());
        }
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(hero,"Error reading file: " + ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
    }
    }
});
}
}
