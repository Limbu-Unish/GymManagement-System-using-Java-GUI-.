package _24046137_Unish_Laxamba;

/**
 * Root class for the Gym Management System.
 * This class contains the common attributes and methods for all gym members.
 * 
 * @author Unish laksamba
 * @version 1.0
 * @since 2023 - 03 - 25
 */

abstract class GymMember
{
    //initializing attributes
    protected int id;
    protected String name;
    protected String location;
    protected String phone;
    protected String email;
    protected String gender;
    protected String DOB;
    protected String membershipStartDate;
    protected int attendance;
    protected double loyaltyPoints;
    protected boolean activeStatus;
    
    /**
     * Constructor for GymMember
     * @param id includes the id if the gymmember
     * @param name includes the name if the gymmember
     * @param location includes the location if the gymmember
     * @param phone includes the phone if the gymmember
     * @param email includes the email if the gymmember
     * @param gender includes the gender if the gymmember
     * @param dob includes the dob if the gymmember
     * @param membershipstartdate includes the membershipstartdate if the gymmember
     */
    public GymMember(int id, String name, String location, String phone, String email, String gender, String DOB, String membershipStartDate){
        this.id = id;
        this.name = name;
        this.location = location;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.DOB = DOB;
        this.membershipStartDate = membershipStartDate;
        this.attendance = 0;
        this.loyaltyPoints = 0.0;
        this.activeStatus = false;
    }
    
    //Accesser method of Attributes
    public int getID(){
        return id;
    }
    
    public String getname(){
        return name;
    }
    
    public String getlocation(){
        return location;
    }
    
    public String getemail(){
        return email;
    }
    
    public String getphone(){
        return phone;
    }
    
    public String getgender(){
        return gender;
    }
    
    public String getDOB(){
        return DOB;
    }
    
    public String getmembershipStartDate(){
        return membershipStartDate;
    }
    
    public int getAttendance(){
        return attendance;    
    }
    
    public double loyaltyPoints(){
        return loyaltyPoints;
    }
    
    public boolean activeStatus(){
        return activeStatus;
    }

    /**
     * An abstract method to mark attendance of the members
     * 
     */
    abstract void markAttendance();
    
    /**
     * A method to active the membership of the members.
     * 
     * In this method the activestatus of the member is set to true.
     */
    public void activeMembership(){
        this.activeStatus = true;
        System.out.println(name + " membership is actived");
    }
    
    /**
     * A method to deactivate the membership of the members.
     * 
     * In this method the activestatus of member is set to false.
     */
    public void deactiveMembership(){
        this.activeStatus = false;
        System.out.println(name + " membership is deactived");
    }
    
    /**
     * A method to reset the members status.
     * 
     * In this method the members activestatus is set to false, attendance is set to 0, and loyaltypoints is set to 0.
     */
    public void resetMember(){
        this.activeStatus = false;
        this.attendance = 0;
        this.loyaltyPoints = 0;
    }
    
    /**
     * A method to show the details of all the members.
     * 
     * @return returns String values which contain all the details of the membrs.
     */
    public String memberdetails(){
        return "ID: " + getID() + "\n" +
        "Name:   " + getname() + "\n" +
        "Email:   " + getemail() + "\n" +
        "Location:   " + getlocation() + "\n" +
        "Phone:   " + getphone() + "\n" +
        "Gender:   " + getgender() + "\n" +
        "DOB:   " + getDOB() + "\n" +
        "MembershipStartDate:   " + getmembershipStartDate() + "\n" + 
        "Attendance:    " + getAttendance() + "\n" +  
        "LoyaltyPoints:   " + loyaltyPoints() + "\n" +
        "ActiveStatus:   " + activeStatus() + "\n";
    }
    
}
